import React, { Suspense, useEffect } from 'react';
import { BrowserRouter as Router } from 'react-router-dom';
import { I18nextProvider } from 'react-i18next';
import CssBaseline from '@mui/material/CssBaseline';
import { ThemeProvider } from '@mui/material/styles';
import { COLORS, lightTheme } from '../src/themev2';
import '@fontsource/open-sauce-one';
import i18n from '../src/i18n';

export const globalTypes = {
  locale: {
    name: 'Locale',
    description: 'Internationalization locale',
    toolbar: {
      icon: 'globe',
      items: [
        { value: 'en', title: 'English' },
        { value: 'es', title: 'Español' },
      ],
      showName: true,
    },
  },
};

export const withMuiTheme = (Story, context) => {
  const { locale } = context.globals;
  useEffect(() => {
    i18n.changeLanguage(locale);
  }, [locale]);
  return (
    <ThemeProvider theme={lightTheme}>
      <Suspense fallback={<div>Loading translations...</div>}>
        <I18nextProvider i18n={i18n}>
          <Router>
            <CssBaseline />
            <div
              style={{
                minHeight: '100vh',
              }}
            >
              <Story />
            </div>
          </Router>
        </I18nextProvider>
      </Suspense>
    </ThemeProvider>
  );
};

export const decorators = [withMuiTheme];
